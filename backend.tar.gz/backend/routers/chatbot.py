from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/chatbot", tags=["Chatbot"])


class ChatMessageIn(BaseModel):
    message: str


class ChatMessageOut(BaseModel):
    reply: str


def _normalize(s: str) -> str:
    return (s or "").strip().lower()


@router.post("/message", response_model=ChatMessageOut)
def chatbot_message(data: ChatMessageIn) -> ChatMessageOut:
    msg = _normalize(data.message)

    # --- Simple FAQ / guided responses ---
    if not msg:
        return ChatMessageOut(reply="Type a question and I’ll help. Examples: 'How do I deposit?', 'What is KYC?', 'How do withdrawals work?'")

    if any(k in msg for k in ["deposit", "fund", "funds", "add money", "make a deposit", "btc wallet", "usdt wallet", "wallet address"]):
        return ChatMessageOut(
            reply=(
                "To deposit: 1) Log in to your account. 2) Go to the Deposit screen. 3) Choose your crypto (BTC/USDT). "
                "4) Copy your unique wallet address and send funds externally. "
                "After admin verification, your deposit will be marked completed and your balance updates."
            )
        )

    if any(k in msg for k in ["withdraw", "withdrawal", "cash out", "send to my wallet", "payout"]):
        return ChatMessageOut(
            reply=(
                "To withdraw: 1) Log in. 2) Open the Wallet/Withdraw screen. 3) Enter the amount and your destination wallet address. "
                "Withdrawals are processed after review. If a withdrawal is rejected, the amount is refunded."
            )
        )

    if any(k in msg for k in ["kyc", "verify", "verification", "passport", "drivers license", "national id", "utility bill"]):
        return ChatMessageOut(
            reply=(
                "KYC is identity verification. Submit documents in the KYC screen (passport / drivers license / national id / utility bill). "
                "Review typically takes 1–24 hours. You cannot make transactions until KYC is approved."
            )
        )

    if any(k in msg for k in ["plan", "plans", "roi", "daily roi", "earnings", "profit"]):
        return ChatMessageOut(
            reply=(
                "Choose a plan based on your timeframe and risk preference. In general, higher plans target higher daily ROI. "
                "Your investment produces daily profits; principal is returned based on the plan duration. "
                "If you tell me your target (e.g., 'I want safer and short term'), I can suggest which plan fits."
            )
        )

    if any(k in msg for k in ["scam", "recovery", "claim", "fraud", "stolen", "chargeback"]):
        return ChatMessageOut(
            reply=(
                "Scam recovery: submit a recovery report from your dashboard. Provide a detailed case description (minimum 50 characters), "
                "and include relevant information (email/mobile, scam type, amount invested). Our team reviews and contacts you. "
                "Recent duplicates may be throttled to prevent spam."
            )
        )

    if any(k in msg for k in ["login", "sign in", "password", "reset password", "forgot"]):
        return ChatMessageOut(
            reply=(
                "For login help: use the Login page. If you forgot your password, open the Reset Password page to set a new one. "
                "If you’re locked out, try again after a few minutes and ensure email/password are correct."
            )
        )

    if any(k in msg for k in ["contact", "support", "help", "agent", "human"]):
        return ChatMessageOut(
            reply=(
                "I can’t directly contact a human from here, but you can submit your issue from the app (e.g., scam report/recovery, or dashboard messages if available). "
                "Tell me what you need help with (deposit/withdraw/KYC/plans) and I’ll guide you step-by-step."
            )
        )

    # --- Fallback ---
    return ChatMessageOut(
        reply=(
            "I’m a customer assistant bot. I can help with:\n"
            "• Deposits & wallet addresses\n"
            "• Withdrawals & processing\n"
            "• KYC verification\n"
            "• Investment plans & ROI\n"
            "• Scam recovery claims\n\n"
            "Ask: “How do I deposit?” or “What is KYC?”"
        )
    )

